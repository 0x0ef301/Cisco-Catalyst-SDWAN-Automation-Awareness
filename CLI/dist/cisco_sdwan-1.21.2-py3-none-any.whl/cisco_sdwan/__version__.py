"""
Sastre-Pro - Cisco-SDWAN Automation Toolset

"""
__copyright__ = "Copyright (c) 2019-2023 Cisco Systems, Inc. and/or its affiliates"
__version__ = "1.21.2"
