"""
Sastre - Cisco-SDWAN Automation Toolset

"""
from .__version__ import __version__, __copyright__
